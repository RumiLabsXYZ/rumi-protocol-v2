import{a as r}from"../chunks/zvgsm9x7.js";import{y as t}from"../chunks/CYVykz7R.js";export{t as load_css,r as start};
