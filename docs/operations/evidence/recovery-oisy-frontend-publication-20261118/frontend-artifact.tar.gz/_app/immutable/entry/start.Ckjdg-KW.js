import{a as r}from"../chunks/D-_E0qK3.js";import{y as t}from"../chunks/QPZd4-rW.js";export{t as load_css,r as start};
