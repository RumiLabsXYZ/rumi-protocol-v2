import{E as p,av as t}from"./BtIODhfX.js";import{B as c}from"./Chkdr1pU.js";function E(a,r,...s){var e=new c(a);p(()=>{const n=r()??null;e.ensure(n,n&&(o=>n(o,...s)))},t)}export{E as s};
