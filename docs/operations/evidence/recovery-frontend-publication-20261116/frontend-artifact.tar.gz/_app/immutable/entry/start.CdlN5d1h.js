import{a as r}from"../chunks/D1Dum8dZ.js";import{y as t}from"../chunks/D5XUzGkA.js";export{t as load_css,r as start};
